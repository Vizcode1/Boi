from AlvinMusicRobot.function.admins import admins
from AlvinMusicRobot.function.admins import get
from AlvinMusicRobot.function.admins import set

__all__ = ["set", "get", "admins"]
